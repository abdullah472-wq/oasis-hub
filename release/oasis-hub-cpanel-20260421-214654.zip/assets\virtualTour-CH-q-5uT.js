import{c as r,q as d,ai as n,l as c,k as i,i as t,ah as u,aj as h,f as l}from"./index-Cx7i97O7.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=r("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]),s="virtual_tours",y=async a=>{const e=await u(c(t,s),{...a,createdAt:Date.now()});return{...a,id:e.id,createdAt:Date.now()}},T=async()=>{const a=d(c(t,s),n("createdAt","desc"));return(await i(a)).docs.map(o=>({id:o.id,...o.data()}))},g=async a=>{await h(l(t,s,a))};export{w as C,y as a,g as d,T as g};
