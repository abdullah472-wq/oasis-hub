import{c as r,q as d,af as n,l as c,k as i,i as t,ae as u,ag as h,f as l}from"./index-CpmepaB3.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=r("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]),s="virtual_tours",w=async a=>{const e=await u(c(t,s),{...a,createdAt:Date.now()});return{...a,id:e.id,createdAt:Date.now()}},y=async()=>{const a=d(c(t,s),n("createdAt","desc"));return(await i(a)).docs.map(o=>({id:o.id,...o.data()}))},T=async a=>{await h(l(t,s,a))};export{p as C,w as a,T as d,y as g};
